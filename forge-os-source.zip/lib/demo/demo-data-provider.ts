import type { DemoSession } from "./session";

import { DemoSessionBuilder } from "./demo-session-builder";

/**
 * Supplies data to the Forge cognitive demo.
 *
 * Today this returns a single demonstration session.
 *
 * In future tickets this class will execute the real kernel,
 * collect semantic artifacts and populate the DemoSession.
 */
export class DemoDataProvider {
  async load(): Promise<DemoSession> {
    return new DemoSessionBuilder().build(
      "Jess helped redesign the memory engine."
    );
  }
}