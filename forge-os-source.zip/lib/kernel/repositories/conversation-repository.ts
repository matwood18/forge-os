export type ConversationRepository = object;
