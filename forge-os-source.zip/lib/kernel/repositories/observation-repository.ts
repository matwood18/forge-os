export type ObservationRepository = object;
