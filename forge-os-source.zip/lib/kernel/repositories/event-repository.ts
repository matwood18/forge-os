export type EventRepository = object;
