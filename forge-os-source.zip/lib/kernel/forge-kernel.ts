import type { Event, Question } from "@/lib/domain";

import {
  CognitivePipeline,
  createDefaultCognitivePipeline,
  DefaultCognitiveContextInitializer,
} from "./cognitive-pipeline";

import { BasicCuriosityEngine } from "./curiosity";
import type { CuriosityEngine } from "./curiosity";

import { EntityService } from "./entity";

import {
  EventBusSubscriberRegistrar,
  InMemoryEventBus,
  type EventBus,
  type EventBusSubscriber,
} from "./event-bus";

import { BasicEventIngestor, InMemoryEventStore } from "./event-store";
import type { EventIngestInput, EventIngestResult } from "./event-store";

import { KernelExecutionRecorder, type KernelExecution } from "./execution";

import {
  BasicIdentityResolutionEngine,
  type IdentityResolutionEngineResult,
} from "./identity-resolution";

import {
  InMemoryMemoryRepository,
  MemoryEngine,
  MemoryService,
  RelationshipMemoryProducer,
} from "./memory";

import type { MemoryRecord } from "./memory";

import {
  InMemoryObservationRepository,
  type ObservationRecord,
  type ObservationRepository,
} from "./observation";

import { InMemoryPersonStore } from "./person-store";

import { InMemoryQuestionStore } from "./question-store";

import {
  BasicArgumentSynthesizer,
  BasicReasoningEngine,
  InMemoryArgumentGeneratorRegistry,
  InMemoryReasoningSessionRepository,
  ObjectiveArgumentGenerator,
  type ReasoningEngine,
  type ReasoningSession,
} from "./reasoning";

import type { EntityRepository } from "./repositories";

import {
  BasicRelationshipEngine,
  createDefaultRelationshipRules,
  InMemoryRelationshipRepository,
  type RelationshipEngine,
  type RelationshipRecord,
  type RelationshipRepository,
} from "./relationship";

import { BasicWorldModelBuilder } from "./world-model";

export type CaptureResult = EventIngestResult;

export type ForgeKernelDependencies = {
  reasoningEngine?: ReasoningEngine;
  observationRepository?: ObservationRepository;
  entityRepository?: EntityRepository;
  relationshipEngine?: RelationshipEngine;
  relationshipRepository?: RelationshipRepository;
  eventBus?: EventBus;
  eventBusSubscribers?: EventBusSubscriber[];
};

type CognitiveRunResult = {
  reasoningSession: ReasoningSession;
  observations: ObservationRecord[];
  relationships: RelationshipRecord[];
  memories: MemoryRecord[];
  questions: Question[];
};

export class ForgeKernel {
  private readonly eventBus: EventBus;
  private readonly eventBusSubscriberRegistrar: EventBusSubscriberRegistrar;

  private readonly eventStore = new InMemoryEventStore();
  private readonly questionStore = new InMemoryQuestionStore();
  private readonly personStore = new InMemoryPersonStore();

  private readonly eventIngestor = new BasicEventIngestor(this.eventStore);

  private readonly reasoningEngine: ReasoningEngine;
  private readonly cognitivePipeline: CognitivePipeline;
  private readonly memory: MemoryService;
  private readonly entityService: EntityService;
  private readonly curiosityEngine: CuriosityEngine;

  private readonly observationRepository: ObservationRepository;

  private readonly relationshipRepository: RelationshipRepository;
  private readonly relationshipEngine: RelationshipEngine;
  private readonly relationshipMemoryProducer = new RelationshipMemoryProducer();

  private readonly identityResolutionEngine =
    new BasicIdentityResolutionEngine(this.personStore);

  constructor(dependencies: ForgeKernelDependencies = {}) {
    this.eventBus = dependencies.eventBus ?? new InMemoryEventBus();

    this.eventBusSubscriberRegistrar = new EventBusSubscriberRegistrar(
      this.eventBus
    );

    this.eventBusSubscriberRegistrar.registerMany(
      dependencies.eventBusSubscribers ?? []
    );

    this.reasoningEngine =
      dependencies.reasoningEngine ?? this.createDefaultReasoningEngine();

    this.observationRepository =
      dependencies.observationRepository ?? new InMemoryObservationRepository();

    this.entityService = new EntityService(dependencies.entityRepository);

    const memoryRepository = new InMemoryMemoryRepository();
    const memoryEngine = new MemoryEngine(memoryRepository);

    this.memory = new MemoryService(memoryEngine);

    this.curiosityEngine = new BasicCuriosityEngine(
      this.personStore,
      dependencies.entityRepository
    );

    this.relationshipRepository =
      dependencies.relationshipRepository ?? new InMemoryRelationshipRepository();

    this.relationshipEngine =
      dependencies.relationshipEngine ??
      new BasicRelationshipEngine(
        this.relationshipRepository,
        createDefaultRelationshipRules()
      );

    const worldModelBuilder = new BasicWorldModelBuilder({
      observationRepository: this.observationRepository,
      relationshipRepository: this.relationshipRepository,
      memoryRepository,
      questionStore: this.questionStore,
    });

    const contextInitializer = new DefaultCognitiveContextInitializer({
      worldModelBuilder,
    });

    this.cognitivePipeline = createDefaultCognitivePipeline({
      environment: {
        reasoningEngine: this.reasoningEngine,
        relationshipEngine: this.relationshipEngine,
        memoryService: this.memory,
        relationshipMemoryProducer: this.relationshipMemoryProducer,
        curiosityEngine: this.curiosityEngine,
        questionStore: this.questionStore,
        observationRepository: this.observationRepository,
      },
      contextInitializer,
    });
  }

  async capture(text: string): Promise<CaptureResult> {
    return this.ingest({
      source: "manual",
      type: "manual.note",
      payload: { text },
    });
  }

  async execute(text: string): Promise<KernelExecution> {
    const recorder = new KernelExecutionRecorder();

    recorder.recordInput(text);

    const ingestResult = await this.eventIngestor.ingest({
      source: "manual",
      type: "manual.note",
      payload: { text },
    });

    recorder.recordEvent(ingestResult.event);

    const cognitiveRun = await this.runCognition(text);

    for (const observation of cognitiveRun.observations) {
      recorder.recordObservation(observation);
    }

    for (const relationship of cognitiveRun.relationships) {
      recorder.recordRelationship(relationship);
    }

    for (const memory of cognitiveRun.memories) {
      recorder.recordMemory(memory);
    }

    recorder.recordReasoning(cognitiveRun.reasoningSession);

    for (const question of cognitiveRun.questions) {
      recorder.recordQuestion(question);
    }

    return recorder.complete(text);
  }

  async people() {
    return this.entityService.all();
  }

  async ingest(input: EventIngestInput): Promise<EventIngestResult> {
    const result = await this.eventIngestor.ingest(input);
    const text = this.getTextFromPayload(input.payload);

    if (!text) {
      return result;
    }

    const cognitiveRun = await this.runCognition(text);

    return {
      ...result,
      questions: cognitiveRun.questions,
    };
  }

  async publish(event: Parameters<EventBus["publish"]>[0]): Promise<void> {
    await this.eventBus.publish(event);
  }

  eventSystem(): EventBus {
    return this.eventBus;
  }

  async answerIdentityQuestion(
    question: Question,
    displayName: string
  ): Promise<IdentityResolutionEngineResult> {
    const result = await this.identityResolutionEngine.answer({
      question,
      displayName,
    });

    await this.entityService.remember({
      type: "PERSON",
      displayName: result.displayName,
    });

    await this.cognitivePipeline.run({ text: question.prompt });

    await this.questionStore.markAnswered(question.id);

    return result;
  }

  async reason(text: string): Promise<ReasoningSession> {
    const result = await this.cognitivePipeline.run({ text });
    const reasoningSession = result.context.artifacts.reasoningSession;

    if (!reasoningSession) {
      throw new Error("Cognitive pipeline completed without reasoning.");
    }

    return reasoningSession;
  }

  async events(): Promise<Event[]> {
    return this.eventStore.list();
  }

  async questions(): Promise<Question[]> {
    return this.questionStore.listOpen();
  }

  async relationships(): Promise<RelationshipRecord[]> {
    return this.relationshipRepository.all();
  }

  async memories(): Promise<MemoryRecord[]> {
    return this.memory.all();
  }

  private createDefaultReasoningEngine(): ReasoningEngine {
    const argumentGeneratorRegistry = new InMemoryArgumentGeneratorRegistry();

    argumentGeneratorRegistry.register(new ObjectiveArgumentGenerator());

    return new BasicReasoningEngine(
      argumentGeneratorRegistry,
      new BasicArgumentSynthesizer(),
      new InMemoryReasoningSessionRepository()
    );
  }

  private async runCognition(text: string): Promise<CognitiveRunResult> {
    const pipelineResult = await this.cognitivePipeline.run({ text });
    const { artifacts } = pipelineResult.context;
    const reasoningSession = artifacts.reasoningSession;

    if (!reasoningSession) {
      throw new Error("Cognitive pipeline completed without reasoning.");
    }

    return {
      reasoningSession,
      observations: artifacts.observations,
      relationships: artifacts.relationships,
      memories: artifacts.memories,
      questions: artifacts.questions,
    };
  }

  private getTextFromPayload(payload: unknown): string | null {
    if (
      typeof payload === "object" &&
      payload !== null &&
      "text" in payload &&
      typeof payload.text === "string"
    ) {
      return payload.text;
    }

    return null;
  }
}